const express = require('express');
const router = express.Router();
const protect = require('../middleware/authMiddleware');
const { getEmployees, addEmployee, updateEmployee, deleteEmployee } = require('../controllers/employeeController');

router.get('/', protect, getEmployees);
router.post('/', protect, addEmployee);
router.put('/:id', protect, updateEmployee);
router.delete('/:id', protect, deleteEmployee);

module.exports = router;